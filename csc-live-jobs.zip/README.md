# CSC ALLIKHERA Live Jobs

Starter files for Firebase + GitHub Actions + web push.

Important: this starter does not scrape SarkariResult.com and does not yet send automatic notifications. A legitimate/public RSS or API source must be configured for the 5-minute job importer.
