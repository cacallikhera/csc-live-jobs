importScripts("https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/10.12.2/firebase-messaging-compat.js");

firebase.initializeApp({
  apiKey:"AIzaSyAHV671ar-n_VB0Y3Vs8RwAiw79KUKzEHA",
  authDomain:"public-portal-csc.firebaseapp.com",
  projectId:"public-portal-csc",
  storageBucket:"public-portal-csc.firebasestorage.app",
  messagingSenderId:"919156057202",
  appId:"1:919156057202:web:badcfc92243ef141d44eeb"
});

const messaging=firebase.messaging();
